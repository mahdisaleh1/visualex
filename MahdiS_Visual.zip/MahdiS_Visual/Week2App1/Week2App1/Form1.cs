﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week2App1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_counter_Click(object sender, EventArgs e)
        {
            int c = Int32.Parse(btn_counter.Text);
            c++;
            btn_counter.Text = c.ToString();
        }

        private void reset_btn_Click(object sender, EventArgs e)
        {
            int m = Int32.Parse(max_lbl.Text);
            int c = Int32.Parse(btn_counter.Text);
            if (c > m)
            {
                max_lbl.Text = c.ToString();
            }
            btn_counter.Text = "0";
            btn_counter.Font = new Font("Microsoft Sans Serif", 10);
            int k = Int32.Parse(rst_nb_lbl.Text);
            k++;
            rst_nb_lbl.Text = k.ToString();
        }

        private void mouse_hover(object sender, EventArgs e)
        {
            
            if (btn_counter.Text == "0")
            {
                btn_counter.Font = new Font("Microsoft Sans Serif", 18);
            }
            else btn_counter.Font = new Font("Microsoft Sans Serif", 18, FontStyle.Bold);
        }
        private void mouse_leave(object sender, EventArgs e)
        {
            if (btn_counter.Text == "0")
            {
                btn_counter.Font = new Font("Microsoft Sans Serif", 14);
            }
            else btn_counter.Font = new Font("Microsoft Sans Serif", 14, FontStyle.Bold);
        }

        private void close_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
