﻿namespace Week2App1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_counter = new System.Windows.Forms.Button();
            this.reset_btn = new System.Windows.Forms.Button();
            this.max_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rst_nb_lbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.close_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_counter
            // 
            this.btn_counter.Location = new System.Drawing.Point(66, 90);
            this.btn_counter.Name = "btn_counter";
            this.btn_counter.Size = new System.Drawing.Size(151, 70);
            this.btn_counter.TabIndex = 0;
            this.btn_counter.Text = "0";
            this.btn_counter.UseVisualStyleBackColor = true;
            this.btn_counter.Click += new System.EventHandler(this.btn_counter_Click);
            this.btn_counter.MouseLeave += new System.EventHandler(this.mouse_leave);
            this.btn_counter.MouseHover += new System.EventHandler(this.mouse_hover);
            // 
            // reset_btn
            // 
            this.reset_btn.AllowDrop = true;
            this.reset_btn.Location = new System.Drawing.Point(102, 227);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 23);
            this.reset_btn.TabIndex = 1;
            this.reset_btn.Text = "reset";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // max_lbl
            // 
            this.max_lbl.AutoSize = true;
            this.max_lbl.Location = new System.Drawing.Point(176, 36);
            this.max_lbl.Name = "max_lbl";
            this.max_lbl.Size = new System.Drawing.Size(13, 13);
            this.max_lbl.TabIndex = 2;
            this.max_lbl.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(99, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Max Numb:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(91, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Reset Numb:";
            // 
            // rst_nb_lbl
            // 
            this.rst_nb_lbl.AutoSize = true;
            this.rst_nb_lbl.Location = new System.Drawing.Point(176, 58);
            this.rst_nb_lbl.Name = "rst_nb_lbl";
            this.rst_nb_lbl.Size = new System.Drawing.Size(13, 13);
            this.rst_nb_lbl.TabIndex = 5;
            this.rst_nb_lbl.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(161, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 6;
            // 
            // close_btn
            // 
            this.close_btn.Location = new System.Drawing.Point(102, 187);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(75, 23);
            this.close_btn.TabIndex = 7;
            this.close_btn.Text = "Close App";
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.ControlBox = false;
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rst_nb_lbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.max_lbl);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.btn_counter);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "MyCounterGame";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_counter;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Label max_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label rst_nb_lbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button close_btn;
    }
}

