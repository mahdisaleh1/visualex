﻿namespace week2app2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.lbl_grade = new System.Windows.Forms.Label();
            this.txt_grade = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_display = new System.Windows.Forms.Button();
            this.txt_display = new System.Windows.Forms.TextBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(33, 39);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(38, 13);
            this.lbl_name.TabIndex = 0;
            this.lbl_name.Text = "Name:";
            // 
            // txt_name
            // 
            this.txt_name.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_name.ForeColor = System.Drawing.SystemColors.Info;
            this.txt_name.Location = new System.Drawing.Point(121, 36);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(123, 20);
            this.txt_name.TabIndex = 1;
            // 
            // lbl_grade
            // 
            this.lbl_grade.AutoSize = true;
            this.lbl_grade.Location = new System.Drawing.Point(32, 74);
            this.lbl_grade.Name = "lbl_grade";
            this.lbl_grade.Size = new System.Drawing.Size(39, 13);
            this.lbl_grade.TabIndex = 2;
            this.lbl_grade.Text = "Grade:";
            // 
            // txt_grade
            // 
            this.txt_grade.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_grade.ForeColor = System.Drawing.SystemColors.Info;
            this.txt_grade.Location = new System.Drawing.Point(121, 71);
            this.txt_grade.Name = "txt_grade";
            this.txt_grade.Size = new System.Drawing.Size(123, 20);
            this.txt_grade.TabIndex = 3;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(26, 106);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(114, 43);
            this.btn_add.TabIndex = 4;
            this.btn_add.Text = "Add New";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_display
            // 
            this.btn_display.Location = new System.Drawing.Point(26, 155);
            this.btn_display.Name = "btn_display";
            this.btn_display.Size = new System.Drawing.Size(114, 45);
            this.btn_display.TabIndex = 5;
            this.btn_display.Text = "Display Grades";
            this.btn_display.UseVisualStyleBackColor = true;
            this.btn_display.Click += new System.EventHandler(this.btn_display_Click);
            // 
            // txt_display
            // 
            this.txt_display.Location = new System.Drawing.Point(163, 106);
            this.txt_display.Multiline = true;
            this.txt_display.Name = "txt_display";
            this.txt_display.ReadOnly = true;
            this.txt_display.Size = new System.Drawing.Size(100, 144);
            this.txt_display.TabIndex = 6;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(26, 206);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(114, 44);
            this.btn_clear.TabIndex = 7;
            this.btn_clear.Text = "Clear Display";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.txt_display);
            this.Controls.Add(this.btn_display);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_grade);
            this.Controls.Add(this.lbl_grade);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lbl_name);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_grade;
        private System.Windows.Forms.TextBox txt_grade;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_display;
        private System.Windows.Forms.TextBox txt_display;
        private System.Windows.Forms.Button btn_clear;
    }
}

