﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week2app2
{
    class student
    {
        private String name;
        private int grade;

        public student(String n, int g)
        {
            name = n;
            grade = g;
        }
        public String Name
        {
            get {
                return name;
            }
            set {
                name= value;
            }
        }
        public int Grade {
            get 
            {
                return grade;
            }
            set
            {
                if (value >= 0) {
                    grade = value;
                }
            }
        }
    }
}
