﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week2app2
{
    public partial class Form1 : Form
    {
        student[] st = new student[10];
        int index = 0; 

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            String name = txt_name.Text;
            int grade = Int32.Parse(txt_grade.Text);
            st[index++] = new student(name, grade);
            txt_grade.Text = "";
            txt_name.Text = "";
            txt_name.Focus();
        }

        private void btn_display_Click(object sender, EventArgs e)
        {
            txt_display.Text = "";
            txt_display.AppendText("Name \t Grade \r\n");
            txt_display.AppendText("---- \t ---- \r\n");
            for(int i=0; i<index; i++){
                txt_display.AppendText(st[i].Name + "\t" + st[i].Grade+"\r\n");
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_display.Text = "";
            txt_name.Focus();
        }


    }
}
